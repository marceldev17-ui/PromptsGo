
import { GeneratedContent } from '../types';

const STORAGE_KEY = 'promptsgo_library';

export const saveToLibrary = (item: GeneratedContent) => {
  const library = getLibrary();
  const updated = [item, ...library];
  localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  return updated;
};

export const getLibrary = (): GeneratedContent[] => {
  const data = localStorage.getItem(STORAGE_KEY);
  return data ? JSON.parse(data) : [];
};

export const removeFromLibrary = (id: string) => {
  const library = getLibrary();
  const updated = library.filter(item => item.id !== id);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  return updated;
};

export const clearLibrary = () => {
  localStorage.removeItem(STORAGE_KEY);
};

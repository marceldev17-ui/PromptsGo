
import { GoogleGenAI } from "@google/genai";
import { Niche, Platform, ImageSize, AspectRatio } from "../types";

const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

// Geração de conteúdo com branding e hashtags
export const generateMarketingContent = async (
  niche: Niche, 
  platform: Platform, 
  additionalContext: string,
  brandName: string,
  logoBase64?: string
) => {
  const ai = getAI();
  
  const promptText = `Crie um post de marketing de alta conversão para a marca "${brandName || 'nossa marca'}" no nicho ${niche} para a plataforma ${platform}. 
  Contexto/Ideia: ${additionalContext}. 
  
  REQUISITOS:
  1. O texto deve ser em Português do Brasil, persuasivo e usar gatilhos mentais.
  2. Mencione o nome da marca "${brandName}" de forma natural.
  3. Formate com um Título chamativo e o Corpo do post.
  4. NO FINAL, inclua uma lista de 5 a 10 hashtags estratégicas em Português para este nicho e plataforma.
  ${logoBase64 ? "5. Analise o estilo visual do logo anexado para ajustar o tom de voz do texto (ex: sofisticado, jovem, profissional)." : ""}`;

  const parts: any[] = [{ text: promptText }];
  
  if (logoBase64) {
    parts.push({
      inlineData: {
        data: logoBase64.split(',')[1],
        mimeType: 'image/png',
      }
    });
  }

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: { parts },
  });

  return response.text;
};

// Geração de calendário semanal
export const generateWeeklyCalendar = async (niche: Niche, brandName: string) => {
  const ai = getAI();
  const prompt = `Crie um calendário de conteúdo de marketing para 7 dias para a marca "${brandName}" no nicho ${niche}.
  Para cada dia, forneça:
  1. Tema do post.
  2. Formato sugerido (Reels, Carrossel, Foto, Story).
  3. Objetivo (Engajamento, Venda, Autoridade).
  4. Melhor horário sugerido.
  Retorne em formato de lista organizada por Dia 1 a Dia 7.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
  });

  return response.text;
};

// Geração de imagem com contexto de marca
export const generateImage = async (
  prompt: string, 
  brandName: string,
  aspectRatio: AspectRatio = '1:1',
  logoBase64?: string
) => {
  const ai = getAI();
  
  const refinedPrompt = `Foto publicitária profissional de alta qualidade para a marca "${brandName}". 
  Assunto: ${prompt}. 
  Estilo: Fotografia comercial, iluminação de estúdio, 8k. 
  ${logoBase64 ? "Tente incorporar elementos visuais, cores ou a estética do logo fornecido na ambientação da imagem." : ""}
  ${brandName ? `Importante: Se possível, inclua sutilmente o nome "${brandName}" em elementos do cenário (ex: uma placa, uniforme ou embalagem).` : ""}`;

  const contents: any = {
    parts: [{ text: refinedPrompt }]
  };

  if (logoBase64) {
    contents.parts.push({
      inlineData: {
        data: logoBase64.split(',')[1],
        mimeType: 'image/png',
      }
    });
  }

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents,
    config: {
      imageConfig: {
        aspectRatio,
      },
    },
  });

  if (response.candidates?.[0]?.content?.parts) {
    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
  }
  return null;
};

export const improveContent = async (originalContent: string) => {
  const ai = getAI();
  const prompt = `Analise o seguinte texto de marketing e sugira 3 melhorias práticas para aumentar a conversão, e também verifique se as hashtags estão otimizadas:\n\n${originalContent}`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
  });

  return response.text;
};

export const editImage = async (base64Image: string, editPrompt: string) => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        {
          inlineData: {
            data: base64Image.split(',')[1],
            mimeType: 'image/png',
          },
        },
        { text: editPrompt },
      ],
    },
  });

  if (response.candidates?.[0]?.content?.parts) {
    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
  }
  return null;
};

export const analyzeImage = async (base64Image: string, query: string) => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        {
          inlineData: {
            data: base64Image.split(',')[1],
            mimeType: 'image/png',
          },
        },
        { text: query },
      ],
    },
  });

  return response.text;
};


import React from 'react';
import { HashRouter, Routes, Route, Link, useLocation } from 'react-router-dom';
import PromptGenerator from './components/PromptGenerator';
import ImageGenerator from './components/ImageGenerator';
import ImageAnalyzer from './components/ImageAnalyzer';
import ChatBot from './components/ChatBot';
import ImageEditor from './components/ImageEditor';
import VideoScriptGenerator from './components/VideoScriptGenerator';
import MarketingCalendar from './components/MarketingCalendar';
import Library from './components/Library';

const Sidebar = () => {
  const location = useLocation();
  const menuItems = [
    { path: '/', label: 'Posts & Hashtags', icon: '📝' },
    { path: '/calendar', label: 'Calendário 7 Dias', icon: '📅' },
    { path: '/videos', label: 'Roteiros de Vídeo', icon: '🎬' },
    { path: '/images', label: 'Criador de Artes', icon: '🖼️' },
    { path: '/editor', label: 'Editor de Fotos AI', icon: '🎨' },
    { path: '/analyzer', label: 'Analisar Anúncio', icon: '🔍' },
    { path: '/chat', label: 'Estrategista AI', icon: '💬' },
    { path: '/library', label: 'Minha Biblioteca', icon: '📚' },
  ];

  return (
    <div className="w-64 bg-slate-900 text-white min-h-screen flex flex-col fixed left-0 top-0 z-50 shadow-2xl">
      <div className="p-8">
        <h1 className="text-2xl font-black bg-gradient-to-r from-blue-400 via-emerald-400 to-purple-500 bg-clip-text text-transparent italic">
          PromptsGo
        </h1>
        <p className="text-[10px] text-slate-500 mt-2 uppercase tracking-[0.2em] font-bold">Marketing Intelligence</p>
      </div>
      <nav className="flex-1 px-4 space-y-1 overflow-y-auto">
        {menuItems.map((item) => (
          <Link
            key={item.path}
            to={item.path}
            className={`flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200 group ${
              location.pathname === item.path 
                ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/50' 
                : 'text-slate-400 hover:bg-slate-800/50 hover:text-white'
            }`}
          >
            <span className={`text-xl transition-transform group-hover:scale-110 ${location.pathname === item.path ? 'scale-110' : ''}`}>{item.icon}</span>
            <span className="font-bold text-sm">{item.label}</span>
          </Link>
        ))}
      </nav>
      <div className="p-6 border-t border-slate-800/50">
        <div className="bg-slate-800/50 rounded-2xl p-4 text-[10px] text-slate-500 border border-slate-700/50">
          <p className="font-bold text-slate-400 mb-1 tracking-widest uppercase">System Status</p>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
            <span>Gemini AI Connected</span>
          </div>
        </div>
      </div>
    </div>
  );
};

const App: React.FC = () => {
  return (
    <HashRouter>
      <div className="flex min-h-screen bg-slate-50">
        <Sidebar />
        <main className="flex-1 ml-64 p-10">
          <div className="max-w-6xl mx-auto">
            <Routes>
              <Route path="/" element={<PromptGenerator />} />
              <Route path="/calendar" element={<MarketingCalendar />} />
              <Route path="/videos" element={<VideoScriptGenerator />} />
              <Route path="/images" element={<ImageGenerator />} />
              <Route path="/editor" element={<ImageEditor />} />
              <Route path="/analyzer" element={<ImageAnalyzer />} />
              <Route path="/chat" element={<ChatBot />} />
              <Route path="/library" element={<Library />} />
            </Routes>
          </div>
        </main>
      </div>
    </HashRouter>
  );
};

export default App;

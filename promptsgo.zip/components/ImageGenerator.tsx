
import React, { useState } from 'react';
import { generateImage } from '../services/geminiService';
import { AspectRatio, Niche } from '../types';
import { NICHES } from '../constants';

type GenerationMode = 'commercial' | 'blog-header';

const ImageGenerator: React.FC = () => {
  const [mode, setMode] = useState<GenerationMode>('commercial');
  const [prompt, setPrompt] = useState('');
  const [brandName, setBrandName] = useState('');
  const [selectedNiche, setSelectedNiche] = useState<Niche>('odontologia');
  const [logo, setLogo] = useState<string | null>(null);
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('1:1');
  const [loading, setLoading] = useState(false);
  const [generatedImageUrl, setGeneratedImageUrl] = useState<string | null>(null);

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setLogo(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleGenerate = async () => {
    if (!prompt) return;

    setLoading(true);
    try {
      let finalPrompt = prompt;
      let finalAspectRatio = aspectRatio;

      if (mode === 'blog-header') {
        const nicheLabel = NICHES.find(n => n.value === selectedNiche)?.label;
        finalPrompt = `Professional blog post header image for a ${nicheLabel} website. Topic: ${prompt}. Cinematic lighting, high quality, minimal copy space on top, sharp focus, clean composition, 8k resolution.`;
        finalAspectRatio = '16:9'; // Padrão para blogs
      }

      const url = await generateImage(finalPrompt, brandName, finalAspectRatio, logo || undefined);
      setGeneratedImageUrl(url);
    } catch (error: any) {
      console.error(error);
      alert('Erro ao gerar imagem. Tente uma descrição mais simples.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 animate-fade-in">
      <header>
        <h2 className="text-3xl font-bold text-slate-800">Criação Visual AI</h2>
        <p className="text-slate-500">Gere artes comerciais ou cabeçalhos de blog em segundos.</p>
      </header>

      {/* Mode Selector */}
      <div className="flex bg-white p-1 rounded-2xl border border-slate-200 shadow-sm max-w-md">
        <button
          onClick={() => { setMode('commercial'); setAspectRatio('1:1'); }}
          className={`flex-1 py-3 px-4 rounded-xl font-bold text-sm transition-all ${mode === 'commercial' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-500 hover:bg-slate-50'}`}
        >
          🖼️ Comercial / Social
        </button>
        <button
          onClick={() => { setMode('blog-header'); setAspectRatio('16:9'); }}
          className={`flex-1 py-3 px-4 rounded-xl font-bold text-sm transition-all ${mode === 'blog-header' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-500 hover:bg-slate-50'}`}
        >
          📰 Cabeçalho de Blog
        </button>
      </div>

      <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 space-y-6">
        {mode === 'commercial' ? (
          /* Branding Info for Commercial Mode */
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-4 bg-indigo-50/50 rounded-xl border border-indigo-100 animate-slide-down">
            <div>
              <label className="block text-sm font-bold text-indigo-800 mb-2">Nome da Marca</label>
              <input
                type="text"
                value={brandName}
                onChange={(e) => setBrandName(e.target.value)}
                placeholder="Para contexto visual..."
                className="w-full bg-white border border-indigo-200 rounded-xl px-4 py-3 text-slate-900 font-medium focus:ring-2 focus:ring-indigo-500 outline-none transition-all placeholder:text-slate-400"
              />
            </div>
            <div>
              <label className="block text-sm font-bold text-indigo-800 mb-2">Logo Referência (Cores)</label>
              <div className="flex items-center space-x-3">
                <label className="flex-1 cursor-pointer bg-white border border-indigo-200 hover:bg-indigo-50 rounded-xl px-4 py-3 text-slate-600 text-sm font-medium transition-all text-center border-dashed">
                  {logo ? "✅ Logo Carregado" : "📁 Carregar Referência"}
                  <input type="file" accept="image/*" onChange={handleLogoUpload} className="hidden" />
                </label>
              </div>
            </div>
          </div>
        ) : (
          /* Niche Selector for Blog Mode */
          <div className="p-4 bg-emerald-50/50 rounded-xl border border-emerald-100 animate-slide-down">
            <label className="block text-sm font-bold text-emerald-800 mb-2">Selecione o Nicho do Blog</label>
            <select
              value={selectedNiche}
              onChange={(e) => setSelectedNiche(e.target.value as Niche)}
              className="w-full bg-white border border-emerald-200 rounded-xl px-4 py-3 text-slate-900 font-medium focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
            >
              {NICHES.map(n => (
                <option key={n.value} value={n.value}>{n.icon} {n.label}</option>
              ))}
            </select>
          </div>
        )}

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            {mode === 'blog-header' ? 'Sobre o que é o artigo?' : 'O que deve aparecer na imagem?'}
          </label>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder={mode === 'blog-header' ? "Ex: Dicas para escovação infantil, ambiente lúdico e educativo..." : "Ex: Uma embalagem de café premium sobre uma mesa rústica..."}
            className="w-full bg-white border border-slate-300 rounded-xl px-4 py-3 text-slate-900 font-medium focus:ring-2 focus:ring-blue-500 outline-none transition-all h-24 placeholder:text-slate-400"
          />
        </div>

        {mode === 'commercial' && (
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">Formato da Imagem</label>
            <div className="flex flex-wrap gap-2">
              {(['1:1', '3:4', '4:3', '9:16', '16:9'] as AspectRatio[]).map((ar) => (
                <button
                  key={ar}
                  onClick={() => setAspectRatio(ar)}
                  className={`flex-1 min-w-[60px] py-2 rounded-lg text-sm font-bold border transition-all ${
                    aspectRatio === ar ? 'bg-indigo-600 border-indigo-600 text-white' : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {ar}
                </button>
              ))}
            </div>
          </div>
        )}

        <button
          onClick={handleGenerate}
          disabled={loading || !prompt}
          className={`w-full text-white font-bold py-4 rounded-xl shadow-lg transition-all flex items-center justify-center space-x-2 disabled:opacity-50 ${mode === 'blog-header' ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-indigo-600 hover:bg-indigo-700'}`}
        >
          {loading ? (
             <div className="flex items-center space-x-2">
               <svg className="animate-spin h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                <span>Criando com IA...</span>
             </div>
          ) : (
            <span>{mode === 'blog-header' ? 'Gerar Cabeçalho de Blog 🚀' : 'Gerar Imagem Comercial 🚀'}</span>
          )}
        </button>
      </div>

      {generatedImageUrl && (
        <div className="bg-white p-4 rounded-2xl shadow-lg border border-slate-100 animate-fade-in">
          <img
            src={generatedImageUrl}
            alt="Generated"
            className="w-full h-auto rounded-xl shadow-inner max-h-[500px] object-contain mx-auto"
          />
          <div className="mt-4 flex justify-between items-center">
            <div className="flex items-center space-x-2">
              <span className="text-sm font-bold text-slate-500 uppercase">Formato {mode === 'blog-header' ? '16:9 (Blog)' : aspectRatio}</span>
              {mode === 'blog-header' && <span className="bg-emerald-100 text-emerald-700 text-[10px] px-2 py-0.5 rounded font-bold">OTIMIZADO PARA WEB</span>}
            </div>
            <a
              href={generatedImageUrl}
              download={`${brandName || (mode === 'blog-header' ? 'blog-header' : 'art')}-promptsgo.png`}
              className="bg-slate-900 text-white px-6 py-2 rounded-lg font-bold text-sm hover:bg-black transition-colors"
            >
              Download
            </a>
          </div>
        </div>
      )}

      {loading && !generatedImageUrl && (
        <div className="bg-white p-12 rounded-2xl border border-dashed border-slate-300 flex flex-col items-center justify-center space-y-4">
          <div className={`w-10 h-10 border-4 border-t-transparent rounded-full animate-spin ${mode === 'blog-header' ? 'border-emerald-600' : 'border-indigo-600'}`}></div>
          <p className="text-slate-600 font-medium text-center">A IA está desenhando {mode === 'blog-header' ? 'seu cabeçalho' : 'sua imagem'}...</p>
        </div>
      )}

      <style>{`
        @keyframes slide-down {
          from { opacity: 0; transform: translateY(-10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-slide-down { animation: slide-down 0.3s ease-out forwards; }
      `}</style>
    </div>
  );
};

export default ImageGenerator;

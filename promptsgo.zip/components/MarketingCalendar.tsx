
import React, { useState } from 'react';
import { generateWeeklyCalendar } from '../services/geminiService';
import { NICHES } from '../constants';
import { Niche } from '../types';
import { saveToLibrary } from '../services/storageService';

const MarketingCalendar: React.FC = () => {
  const [niche, setNiche] = useState<Niche>('odontologia');
  const [brandName, setBrandName] = useState('');
  const [loading, setLoading] = useState(false);
  const [calendar, setCalendar] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!brandName) {
      alert('Por favor, digite o nome da marca para personalizar o calendário.');
      return;
    }
    setLoading(true);
    try {
      const result = await generateWeeklyCalendar(niche, brandName);
      setCalendar(result || '');
    } catch (error) {
      alert('Erro ao gerar calendário.');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = () => {
    if (!calendar) return;
    saveToLibrary({
      id: Date.now().toString(),
      type: 'text',
      niche,
      platform: 'instagram',
      title: `Calendário Semanal: ${brandName}`,
      content: calendar,
      timestamp: Date.now(),
      brandName
    });
    alert('Planejamento salvo na biblioteca! 📚');
  };

  return (
    <div className="space-y-8 animate-fade-in">
      <header>
        <h2 className="text-3xl font-bold text-slate-800">Calendário Estratégico 7 Dias</h2>
        <p className="text-slate-500">Planeje uma semana inteira de postagens para sua marca ou cliente.</p>
      </header>

      <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Nome da Marca</label>
            <input 
              type="text" 
              value={brandName} 
              onChange={(e) => setBrandName(e.target.value)}
              placeholder="Ex: Sorriso Dental"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-900 font-medium outline-none focus:ring-2 focus:ring-blue-500 transition-all"
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Nicho</label>
            <select value={niche} onChange={(e) => setNiche(e.target.value as Niche)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-900 font-medium outline-none">
              {NICHES.map(n => <option key={n.value} value={n.value}>{n.icon} {n.label}</option>)}
            </select>
          </div>
        </div>

        <button 
          onClick={handleGenerate} 
          disabled={loading || !brandName}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {loading ? 'Criando Estratégia...' : 'Gerar Cronograma de 1 Semana 📅'}
        </button>
      </div>

      {calendar && (
        <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-md animate-slide-down">
          <div className="flex justify-between items-center mb-6">
            <h3 className="font-bold text-slate-800 text-xl">Cronograma para {brandName}</h3>
            <div className="flex gap-2">
              <button onClick={() => { navigator.clipboard.writeText(calendar); alert('Copiado!'); }} className="text-xs font-bold bg-slate-100 px-3 py-2 rounded-lg hover:bg-slate-200">Copiar Tudo</button>
              <button onClick={handleSave} className="text-xs font-bold bg-blue-100 text-blue-700 px-3 py-2 rounded-lg hover:bg-blue-200">Salvar Planejamento</button>
            </div>
          </div>
          <div className="bg-slate-50 rounded-2xl p-6 border border-slate-100">
            <p className="whitespace-pre-wrap text-slate-800 leading-relaxed font-medium text-sm">{calendar}</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default MarketingCalendar;

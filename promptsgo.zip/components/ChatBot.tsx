
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import { ChatMessage } from '../types';

const ChatBot: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'model', text: 'Olá! Sou o assistente do PromptsGo. Como posso ajudar na sua estratégia de marketing hoje?', timestamp: Date.now() }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMsg: ChatMessage = { role: 'user', text: input, timestamp: Date.now() };
    const currentInput = input;
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const history = messages.map(m => ({
        role: m.role,
        parts: [{ text: m.text }]
      }));

      const chat = ai.chats.create({
        model: 'gemini-3-flash-preview',
        config: {
          systemInstruction: 'Você é um consultor sênior de marketing digital brasileiro. Ajude o usuário com estratégias práticas.',
        },
        history: history,
      });

      const response = await chat.sendMessage({ message: currentInput });
      
      const modelMsg: ChatMessage = { 
        role: 'model', 
        text: response.text || 'Tive um problema ao processar.', 
        timestamp: Date.now() 
      };
      setMessages(prev => [...prev, modelMsg]);
    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { role: 'model', text: 'Erro de conexão.', timestamp: Date.now() }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="h-[calc(100vh-120px)] flex flex-col bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
      <div className="p-4 border-b border-slate-100 bg-white flex items-center space-x-3">
        <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center text-white text-xl">
          🤖
        </div>
        <div>
          <h3 className="font-bold text-slate-800">Estrategista PromptsGo</h3>
          <span className="text-xs text-green-500 font-medium flex items-center">Online</span>
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-4 bg-slate-50">
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] rounded-2xl px-4 py-3 ${
              m.role === 'user' ? 'bg-blue-600 text-white' : 'bg-white text-slate-900 shadow-sm border border-slate-100'
            }`}>
              <p className="text-sm whitespace-pre-wrap leading-relaxed font-medium">{m.text}</p>
            </div>
          </div>
        ))}
        {loading && <div className="text-xs text-slate-400 animate-pulse">Pensando...</div>}
      </div>

      <div className="p-4 border-t border-slate-100 bg-white">
        <form onSubmit={(e) => { e.preventDefault(); handleSend(); }} className="flex space-x-3">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Digite sua dúvida de marketing..."
            className="flex-1 bg-white border border-slate-300 rounded-xl px-4 py-3 text-slate-900 font-medium focus:ring-2 focus:ring-blue-500 outline-none transition-all placeholder:text-slate-400"
          />
          <button
            type="submit"
            disabled={!input.trim() || loading}
            className="bg-blue-600 hover:bg-blue-700 text-white w-12 h-12 rounded-xl flex items-center justify-center disabled:opacity-50"
          >
            🚀
          </button>
        </form>
      </div>
    </div>
  );
};

export default ChatBot;

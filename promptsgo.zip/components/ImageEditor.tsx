
import React, { useState } from 'react';
import { editImage } from '../services/geminiService';

const ImageEditor: React.FC = () => {
  const [sourceImage, setSourceImage] = useState<string | null>(null);
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState<string[]>([]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setSourceImage(result);
        setHistory([result]);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleEdit = async () => {
    if (!sourceImage || !prompt) return;
    setLoading(true);
    try {
      const result = await editImage(sourceImage, prompt);
      if (result) {
        setSourceImage(result);
        setHistory(prev => [...prev, result]);
        setPrompt('');
      }
    } catch (error) {
      console.error(error);
      alert('Erro ao editar imagem.');
    } finally {
      setLoading(false);
    }
  };

  const undo = () => {
    if (history.length > 1) {
      const newHistory = history.slice(0, -1);
      setHistory(newHistory);
      setSourceImage(newHistory[newHistory.length - 1]);
    }
  };

  return (
    <div className="space-y-8">
      <header>
        <h2 className="text-3xl font-bold text-slate-800">Editor AI Magic</h2>
        <p className="text-slate-500">Edite suas fotos usando apenas comandos de voz ou texto. "Remova o fundo", "Adicione um filtro retrô", etc.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100 flex items-center justify-center min-h-[400px]">
            {sourceImage ? (
              <img src={sourceImage} alt="Canvas" className="max-w-full max-h-[600px] rounded-lg shadow-sm" />
            ) : (
              <div className="text-center p-12 border-2 border-dashed border-slate-200 rounded-xl w-full">
                <svg className="w-16 h-16 text-slate-300 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4"></path>
                </svg>
                <p className="text-slate-500">Faça upload de uma foto para começar a editar</p>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileChange}
                  className="mt-4 text-sm text-slate-600 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                />
              </div>
            )}
          </div>
          
          {sourceImage && (
            <div className="flex justify-between">
              <button
                onClick={undo}
                disabled={history.length <= 1}
                className="text-sm font-bold text-slate-400 hover:text-slate-700 disabled:opacity-30"
              >
                ↩ Desfazer Alteração
              </button>
              <div className="flex space-x-2">
                 <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileChange}
                  className="hidden"
                  id="re-upload"
                />
                <label htmlFor="re-upload" className="text-sm font-bold text-blue-600 cursor-pointer">Trocar Foto</label>
              </div>
            </div>
          )}
        </div>

        <div className="space-y-6">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
            <h3 className="font-bold text-slate-800 mb-4">Comando de Edição</h3>
            <div className="space-y-4">
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Ex: Transforme em uma pintura a óleo, adicione óculos escuros na pessoa, mude o fundo para uma praia..."
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-purple-500 outline-none transition-all h-32 text-sm"
              />
              <button
                onClick={handleEdit}
                disabled={loading || !sourceImage || !prompt}
                className="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 rounded-xl transition-all disabled:opacity-50 flex items-center justify-center space-x-2"
              >
                {loading ? 'Processando Edição...' : (
                  <>
                    <span>Aplicar Mágica</span>
                    <span>🪄</span>
                  </>
                )}
              </button>
            </div>

            <div className="mt-8 space-y-2">
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Sugestões Rápidas</p>
              {['Remover fundo', 'Filtro vintage', 'Transformar em anime', 'Adicionar logo'].map((suggestion) => (
                <button
                  key={suggestion}
                  onClick={() => setPrompt(suggestion)}
                  className="w-full text-left px-3 py-2 text-xs font-medium text-slate-600 hover:bg-slate-50 rounded-lg border border-slate-100 transition-colors"
                >
                  + {suggestion}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ImageEditor;

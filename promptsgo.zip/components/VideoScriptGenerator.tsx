
import React, { useState } from 'react';
import { GoogleGenAI } from "@google/genai";
import { NICHES } from '../constants';
import { Niche } from '../types';
import { saveToLibrary } from '../services/storageService';

const VideoScriptGenerator: React.FC = () => {
  const [niche, setNiche] = useState<Niche>('odontologia');
  const [topic, setTopic] = useState('');
  const [duration, setDuration] = useState('30s');
  const [loading, setLoading] = useState(false);
  const [script, setScript] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!topic) return;
    setLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `Crie um roteiro viral de vídeo curto (${duration}) para o nicho ${niche}. 
      Tema: ${topic}. 
      Divida em: 
      1. Gancho (primeiros 3 segundos)
      2. Conteúdo/Corpo
      3. Chamada para ação (CTA)
      4. Sugestões Visuais (o que mostrar na tela).
      Linguagem dinâmica e rápida em Português do Brasil.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
      });

      setScript(response.text || '');
    } catch (error) {
      alert('Erro ao gerar roteiro.');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = () => {
    if (!script) return;
    saveToLibrary({
      id: Date.now().toString(),
      type: 'video-script',
      niche,
      platform: 'tiktok',
      title: `Roteiro: ${topic}`,
      content: script,
      timestamp: Date.now()
    });
    alert('Roteiro salvo na biblioteca!');
  };

  return (
    <div className="space-y-8 animate-fade-in">
      <header>
        <h2 className="text-3xl font-bold text-slate-800">Roteirista de Vídeos Virais</h2>
        <p className="text-slate-500">Gere scripts prontos para Reels, TikTok e Shorts.</p>
      </header>

      <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Nicho</label>
            <select value={niche} onChange={(e) => setNiche(e.target.value as Niche)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-900 font-medium outline-none">
              {NICHES.map(n => <option key={n.value} value={n.value}>{n.icon} {n.label}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Duração Estimada</label>
            <select value={duration} onChange={(e) => setDuration(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-900 font-medium outline-none">
              <option value="15s">15 Segundos (Rápido)</option>
              <option value="30s">30 Segundos (Ideal)</option>
              <option value="60s">60 Segundos (Educativo)</option>
            </select>
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Qual o tema do vídeo?</label>
          <input 
            type="text" 
            value={topic} 
            onChange={(e) => setTopic(e.target.value)}
            placeholder="Ex: 3 mitos sobre clareamento dental..."
            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-900 font-medium outline-none"
          />
        </div>

        <button 
          onClick={handleGenerate} 
          disabled={loading || !topic}
          className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-4 rounded-xl shadow-lg shadow-emerald-100 transition-all flex items-center justify-center gap-2"
        >
          {loading ? 'Criando Roteiro...' : 'Gerar Roteiro Viral 🎬'}
        </button>
      </div>

      {script && (
        <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-md animate-slide-down">
          <div className="flex justify-between items-center mb-6">
            <h3 className="font-bold text-slate-800 text-xl">Roteiro Sugerido</h3>
            <div className="flex gap-2">
              <button onClick={() => { navigator.clipboard.writeText(script); alert('Copiado!'); }} className="text-xs font-bold bg-slate-100 px-3 py-2 rounded-lg hover:bg-slate-200">Copiar</button>
              <button onClick={handleSave} className="text-xs font-bold bg-emerald-100 text-emerald-700 px-3 py-2 rounded-lg hover:bg-emerald-200">Salvar na Biblioteca</button>
            </div>
          </div>
          <div className="bg-slate-50 rounded-2xl p-6 border border-slate-100">
            <p className="whitespace-pre-wrap text-slate-800 leading-relaxed font-medium">{script}</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default VideoScriptGenerator;

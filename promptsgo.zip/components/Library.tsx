
import React, { useState, useEffect } from 'react';
import { getLibrary, removeFromLibrary } from '../services/storageService';
import { GeneratedContent } from '../types';

const Library: React.FC = () => {
  const [items, setItems] = useState<GeneratedContent[]>([]);

  useEffect(() => {
    setItems(getLibrary());
  }, []);

  const handleDelete = (id: string) => {
    if (confirm('Deseja excluir este item da biblioteca?')) {
      const updated = removeFromLibrary(id);
      setItems(updated);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert('Conteúdo copiado!');
  };

  return (
    <div className="space-y-8 animate-fade-in">
      <header>
        <h2 className="text-3xl font-bold text-slate-800">Minha Biblioteca</h2>
        <p className="text-slate-500">Seu acervo particular de estratégias e artes.</p>
      </header>

      {items.length === 0 ? (
        <div className="bg-white rounded-2xl p-12 text-center border border-slate-100">
          <div className="text-5xl mb-4">📚</div>
          <h3 className="text-xl font-bold text-slate-800">Sua biblioteca está vazia</h3>
          <p className="text-slate-500 mt-2">Comece a gerar conteúdos e clique em "Salvar" para vê-los aqui.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {items.map((item) => (
            <div key={item.id} className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-md transition-all flex flex-col">
              {item.imageUrl && (
                <img src={item.imageUrl} alt={item.title} className="w-full h-48 object-cover border-b border-slate-100" />
              )}
              <div className="p-5 flex-1 flex flex-col">
                <div className="flex justify-between items-start mb-3">
                  <span className={`text-[10px] font-bold px-2 py-1 rounded uppercase tracking-wider ${
                    item.type === 'text' ? 'bg-blue-100 text-blue-700' : 
                    item.type === 'image' ? 'bg-purple-100 text-purple-700' : 'bg-emerald-100 text-emerald-700'
                  }`}>
                    {item.type} • {item.platform}
                  </span>
                  <button onClick={() => handleDelete(item.id)} className="text-slate-300 hover:text-red-500 transition-colors">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                  </button>
                </div>
                <h3 className="font-bold text-slate-800 mb-2">{item.title}</h3>
                <p className="text-sm text-slate-600 line-clamp-4 flex-1">{item.content}</p>
                <div className="mt-4 pt-4 border-t border-slate-50 flex gap-2">
                  <button 
                    onClick={() => copyToClipboard(item.content)}
                    className="flex-1 bg-slate-900 text-white text-xs font-bold py-2 rounded-lg hover:bg-blue-600 transition-colors"
                  >
                    Copiar
                  </button>
                  {item.imageUrl && (
                    <a 
                      href={item.imageUrl} 
                      download="criação.png"
                      className="px-3 bg-slate-100 text-slate-600 rounded-lg flex items-center justify-center hover:bg-slate-200 transition-colors"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                      </svg>
                    </a>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Library;

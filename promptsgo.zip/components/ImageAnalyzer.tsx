
import React, { useState } from 'react';
import { analyzeImage } from '../services/geminiService';

const ImageAnalyzer: React.FC = () => {
  const [image, setImage] = useState<string | null>(null);
  const [query, setQuery] = useState('Como esta imagem pode ser melhorada para marketing?');
  const [loading, setLoading] = useState(false);
  const [analysis, setAnalysis] = useState('');

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setImage(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleAnalyze = async () => {
    if (!image) return;
    setLoading(true);
    try {
      const result = await analyzeImage(image, query);
      setAnalysis(result || 'Falha na análise.');
    } catch (error) {
      alert('Erro ao analisar.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <header>
        <h2 className="text-3xl font-bold text-slate-800">Analisador de Imagem AI</h2>
        <p className="text-slate-500">Feedback gratuito para seus anúncios.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
             <div className="relative border-2 border-dashed rounded-xl p-8 flex flex-col items-center justify-center bg-white border-slate-300">
              {image ? <img src={image} className="max-h-64 rounded-lg" /> : <p className="text-slate-400">Clique para enviar imagem</p>}
              <input type="file" onChange={handleFileChange} className="absolute inset-0 opacity-0 cursor-pointer" />
            </div>
          </div>

          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
            <textarea
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="w-full bg-white border border-slate-300 rounded-xl px-4 py-3 text-slate-900 font-medium focus:ring-2 focus:ring-blue-500 outline-none transition-all h-24"
            />
            <button onClick={handleAnalyze} disabled={loading || !image} className="w-full mt-4 bg-emerald-600 text-white font-bold py-3 rounded-xl disabled:opacity-50">
              {loading ? 'Analisando...' : 'Analisar Agora'}
            </button>
          </div>
        </div>

        <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
          <h3 className="font-bold text-slate-800 mb-4">Feedback da IA:</h3>
          <p className="text-slate-900 font-medium whitespace-pre-wrap">{analysis || 'Aguardando imagem...'}</p>
        </div>
      </div>
    </div>
  );
};

export default ImageAnalyzer;

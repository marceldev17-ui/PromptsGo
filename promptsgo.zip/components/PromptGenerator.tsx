
import React, { useState } from 'react';
import { NICHES, PLATFORMS } from '../constants';
import { Niche, Platform, GeneratedContent } from '../types';
import { generateMarketingContent, improveContent } from '../services/geminiService';
import { saveToLibrary } from '../services/storageService';

const PromptGenerator: React.FC = () => {
  const [activeStep, setActiveStep] = useState<number>(1);
  const [niche, setNiche] = useState<Niche>('odontologia');
  const [platform, setPlatform] = useState<Platform>('instagram');
  const [brandName, setBrandName] = useState('');
  const [logo, setLogo] = useState<string | null>(null);
  const [context, setContext] = useState('');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<(GeneratedContent & { improvements?: string })[]>([]);

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setLogo(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleGenerate = async (overriddenContext?: string) => {
    const finalContext = overriddenContext || context;
    if (!finalContext.trim() && !overriddenContext) return;

    setLoading(true);
    try {
      const text = await generateMarketingContent(
        niche, 
        platform, 
        finalContext, 
        brandName, 
        logo || undefined
      );
      
      const newContent: GeneratedContent = {
        id: Date.now().toString(),
        niche,
        platform,
        type: 'text',
        title: `${brandName || 'Post'} - ${PLATFORMS.find(p => p.value === platform)?.label}`,
        content: text || 'Falha ao gerar conteúdo.',
        timestamp: Date.now(),
        brandName
      };
      setResults([newContent, ...results]);
    } catch (error) {
      console.error(error);
      alert('Erro ao gerar conteúdo.');
    } finally {
      setLoading(false);
    }
  };

  const handleSaveItem = (item: GeneratedContent) => {
    saveToLibrary(item);
    alert('Salvo na sua biblioteca! 📚');
  };

  const handleImprove = async (id: string, content: string) => {
    setLoading(true);
    try {
      const improvements = await improveContent(content);
      setResults(prev => prev.map(item => item.id === id ? { ...item, improvements } : item));
    } catch (error) {
      alert('Erro ao buscar melhorias.');
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert('Copiado com sucesso!');
  };

  const selectedNicheData = NICHES.find(n => n.value === niche);

  return (
    <div className="space-y-8 animate-fade-in">
      <header className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-800 tracking-tight">Gerador de Conteúdo AI</h2>
          <p className="text-slate-500 mt-1">Crie estratégias de marketing personalizadas em 3 passos simples.</p>
        </div>
        {results.length > 0 && (
          <button 
            onClick={() => { if(confirm('Limpar resultados?')) setResults([]); }}
            className="text-xs font-bold text-slate-400 hover:text-red-500 uppercase tracking-widest transition-colors"
          >
            Limpar Resultados
          </button>
        )}
      </header>

      <div className="flex flex-col gap-4">
        {/* STEP 1: BRANDING */}
        <div className={`bg-white rounded-2xl border transition-all duration-300 ${activeStep === 1 ? 'border-blue-500 shadow-lg ring-1 ring-blue-50' : 'border-slate-200 shadow-sm'}`}>
          <button 
            onClick={() => setActiveStep(1)}
            className="w-full flex items-center justify-between p-5 text-left"
          >
            <div className="flex items-center gap-4">
              <span className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${activeStep === 1 ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-400'}`}>1</span>
              <div>
                <h3 className="font-bold text-slate-800">Identidade da Marca</h3>
                {activeStep !== 1 && brandName && <p className="text-xs text-blue-600 font-medium">Marca: {brandName}</p>}
              </div>
            </div>
            <svg className={`w-5 h-5 text-slate-400 transition-transform ${activeStep === 1 ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
            </svg>
          </button>
          
          {activeStep === 1 && (
            <div className="px-5 pb-6 space-y-4 animate-slide-down">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Nome do Cliente / Marca</label>
                  <input
                    type="text"
                    value={brandName}
                    onChange={(e) => setBrandName(e.target.value)}
                    placeholder="Ex: Clínica Sorriso, Moda Chic..."
                    className="w-full bg-white border border-slate-300 rounded-xl px-4 py-3 text-slate-900 font-medium focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Logo de Referência</label>
                  <div className="flex items-center gap-3">
                    <label className="flex-1 cursor-pointer bg-slate-50 border border-slate-200 border-dashed hover:bg-blue-50 rounded-xl px-4 py-3 text-slate-600 text-sm font-medium transition-all text-center">
                      {logo ? "✅ Logo Carregado" : "📁 Carregar Logo"}
                      <input type="file" accept="image/*" onChange={handleLogoUpload} className="hidden" />
                    </label>
                    {logo && <button onClick={() => setLogo(null)} className="p-3 bg-red-50 text-red-500 rounded-xl">🗑️</button>}
                  </div>
                </div>
              </div>
              <div className="flex justify-end">
                <button onClick={() => setActiveStep(2)} className="bg-blue-600 text-white px-6 py-2 rounded-lg font-bold text-sm shadow-md">Próximo Passo</button>
              </div>
            </div>
          )}
        </div>

        {/* STEP 2: SEGMENTATION */}
        <div className={`bg-white rounded-2xl border transition-all duration-300 ${activeStep === 2 ? 'border-blue-500 shadow-lg ring-1 ring-blue-50' : 'border-slate-200 shadow-sm'}`}>
          <button 
            onClick={() => setActiveStep(2)}
            className="w-full flex items-center justify-between p-5 text-left"
          >
            <div className="flex items-center gap-4">
              <span className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${activeStep === 2 ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-400'}`}>2</span>
              <div>
                <h3 className="font-bold text-slate-800">Público e Plataforma</h3>
                {activeStep !== 2 && <p className="text-xs text-blue-600 font-medium">{NICHES.find(n => n.value === niche)?.label} • {PLATFORMS.find(p => p.value === platform)?.label}</p>}
              </div>
            </div>
            <svg className={`w-5 h-5 text-slate-400 transition-transform ${activeStep === 2 ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
            </svg>
          </button>
          
          {activeStep === 2 && (
            <div className="px-5 pb-6 space-y-4 animate-slide-down">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Nicho do Mercado</label>
                  <select
                    value={niche}
                    onChange={(e) => setNiche(e.target.value as Niche)}
                    className="w-full bg-white border border-slate-300 rounded-xl px-4 py-3 text-slate-900 font-medium outline-none transition-all"
                  >
                    {NICHES.map(n => <option key={n.value} value={n.value}>{n.icon} {n.label}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Canal de Publicação</label>
                  <select
                    value={platform}
                    onChange={(e) => setPlatform(e.target.value as Platform)}
                    className="w-full bg-white border border-slate-300 rounded-xl px-4 py-3 text-slate-900 font-medium outline-none transition-all"
                  >
                    {PLATFORMS.map(p => <option key={p.value} value={p.value}>{p.label}</option>)}
                  </select>
                </div>
              </div>
              <div className="flex justify-between">
                <button onClick={() => setActiveStep(1)} className="text-slate-500 font-bold text-sm">Voltar</button>
                <button onClick={() => setActiveStep(3)} className="bg-blue-600 text-white px-6 py-2 rounded-lg font-bold text-sm shadow-md">Próximo Passo</button>
              </div>
            </div>
          )}
        </div>

        {/* STEP 3: CREATION */}
        <div className={`bg-white rounded-2xl border transition-all duration-300 ${activeStep === 3 ? 'border-blue-500 shadow-lg ring-1 ring-blue-50' : 'border-slate-200 shadow-sm'}`}>
          <button 
            onClick={() => setActiveStep(3)}
            className="w-full flex items-center justify-between p-5 text-left"
          >
            <div className="flex items-center gap-4">
              <span className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${activeStep === 3 ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-400'}`}>3</span>
              <div>
                <h3 className="font-bold text-slate-800">Conteúdo e Mensagem</h3>
              </div>
            </div>
          </button>
          
          {activeStep === 3 && (
            <div className="px-5 pb-6 space-y-6 animate-slide-down">
              {selectedNicheData?.templates && (
                <div className="space-y-3">
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider">Ideias Rápidas</label>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                    {selectedNicheData.templates.map((t, idx) => (
                      <button key={idx} onClick={() => { setContext(t); handleGenerate(t); }} className="text-left bg-slate-50 border border-slate-200 p-3 rounded-xl text-xs text-slate-700 font-medium hover:bg-blue-50">{t}</button>
                    ))}
                  </div>
                </div>
              )}

              <textarea
                value={context}
                onChange={(e) => setContext(e.target.value)}
                placeholder="Ex: Fale sobre a nova promoção de clareamento..."
                className="w-full bg-white border border-slate-300 rounded-2xl px-5 py-4 text-slate-900 font-medium h-32 outline-none"
              />

              <div className="flex items-center justify-between gap-4">
                <button onClick={() => setActiveStep(2)} className="text-slate-500 font-bold text-sm">Voltar</button>
                <button
                  onClick={() => handleGenerate()}
                  disabled={loading || !context.trim()}
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-xl shadow-lg flex items-center justify-center space-x-3 disabled:opacity-50"
                >
                  {loading ? <span>Processando...</span> : <span>Gerar Post com IA 🚀</span>}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* RESULTS FEED */}
      <div className="space-y-6">
        {results.map((item) => (
          <div key={item.id} className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm animate-fade-in group">
            <div className="flex justify-between items-start mb-6">
              <div className="flex items-center gap-3">
                <div className="bg-blue-50 p-2 rounded-xl text-lg">✨</div>
                <div>
                  <h3 className="font-bold text-slate-800 text-lg leading-tight">{item.title}</h3>
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-tighter">{item.platform}</span>
                </div>
              </div>
              <div className="flex gap-2">
                <button onClick={() => handleSaveItem(item)} className="bg-emerald-50 text-emerald-600 px-4 py-2 rounded-xl font-bold text-xs hover:bg-emerald-100 transition-all">Salvar</button>
                <button onClick={() => copyToClipboard(item.content)} className="bg-slate-900 text-white px-4 py-2 rounded-xl font-bold text-xs hover:bg-blue-600 transition-all">Copiar</button>
              </div>
            </div>
            <div className="bg-slate-50 rounded-2xl p-6 border border-slate-100">
              <p className="whitespace-pre-wrap text-slate-900 font-medium leading-relaxed text-sm">{item.content}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PromptGenerator;

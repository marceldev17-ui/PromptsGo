
export type Niche = 'odontologia' | 'moda' | 'esoterismo' | 'gastronomia' | 'imobiliaria' | 'tecnologia' | 'estetica' | 'fitness' | 'petshop' | 'advocacia';

export type Platform = 'instagram' | 'facebook' | 'blog' | 'google-ads' | 'meta-ads' | 'site' | 'tiktok' | 'youtube';

export interface GeneratedContent {
  id: string;
  niche: Niche;
  platform: Platform;
  title: string;
  content: string;
  imageUrl?: string;
  timestamp: number;
  type: 'text' | 'image' | 'video-script';
  brandName?: string;
}

export type ImageSize = '1K' | '2K' | '4K';
export type AspectRatio = '1:1' | '3:4' | '4:3' | '9:16' | '16:9';

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  timestamp: number;
}

export interface VideoScript {
  hook: string;
  body: string;
  callToAction: string;
  visualSuggestions: string;
}

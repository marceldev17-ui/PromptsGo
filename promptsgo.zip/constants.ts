
import { Niche, Platform } from './types';

export const NICHES: { value: Niche; label: string; icon: string; templates: string[] }[] = [
  { 
    value: 'odontologia', 
    label: 'Odontologia', 
    icon: '🦷',
    templates: [
      "Benefícios do clareamento a laser para sua auto-estima.",
      "5 sinais de que você precisa visitar o dentista urgente.",
      "A importância do fio dental explicada de forma simples."
    ]
  },
  { 
    value: 'moda', 
    label: 'Moda & Roupas', 
    icon: '👕',
    templates: [
      "Tendências de Outono/Inverno que você precisa conhecer.",
      "Como montar 3 looks diferentes com uma peça básica.",
      "Bastidores da nossa nova coleção chegando na loja."
    ]
  },
  { 
    value: 'esoterismo', 
    label: 'Loja Esotérica', 
    icon: '🔮',
    templates: [
      "O significado das pedras naturais no seu dia a dia.",
      "Como fazer um ritual de limpeza energética em casa.",
      "Previsões astrológicas para a próxima Lua Cheia."
    ]
  },
  { 
    value: 'gastronomia', 
    label: 'Gastronomia', 
    icon: '🍕',
    templates: [
      "O segredo do nosso molho especial revelado.",
      "Por que nossa pizza é a favorita da cidade?",
      "Dica de harmonização de vinhos para o seu jantar."
    ]
  },
  { 
    value: 'imobiliaria', 
    label: 'Imobiliária', 
    icon: '🏠',
    templates: [
      "Oportunidade: O primeiro imóvel com parcelas menores que aluguel.",
      "O que observar antes de assinar um contrato de compra.",
      "Tour virtual pelo apartamento dos seus sonhos."
    ]
  },
  { value: 'tecnologia', label: 'Tecnologia', icon: '💻', templates: ["Gadgets que facilitam o home office.", "Review sincero do novo smartphone.", "Dicas de segurança digital."] },
  { value: 'estetica', label: 'Estética & Beleza', icon: '💄', templates: ["Rotina de skincare para peles oleosas.", "Antes e depois: Harmonização facial.", "Mitos e verdades sobre depilação a laser."] },
  { value: 'fitness', label: 'Fitness & Saúde', icon: '💪', templates: ["Treino de 15 minutos para quem não tem tempo.", "A importância da proteína na sua dieta.", "Como manter a motivação nos treinos."] },
  { value: 'petshop', label: 'Pet Shop', icon: '🐾', templates: ["Dicas para acalmar seu pet em dias de chuva.", "A melhor ração para cada fase da vida.", "Higiene bucal em cães: Como fazer?"] },
  { value: 'advocacia', label: 'Advocacia', icon: '⚖️', templates: ["Seus direitos ao comprar online.", "Como funciona o processo de herança.", "Dicas para pequenas empresas evitarem processos."] },
];

export const PLATFORMS: { value: Platform; label: string }[] = [
  { value: 'instagram', label: 'Instagram (Post/Reels)' },
  { value: 'facebook', label: 'Facebook' },
  { value: 'blog', label: 'Blog Post' },
  { value: 'google-ads', label: 'Google Ads' },
  { value: 'meta-ads', label: 'Meta Ads' },
  { value: 'site', label: 'Site Content' },
];
